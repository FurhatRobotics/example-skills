package iristk.app.presentation;

import java.util.List;
import java.io.File;
import iristk.xml.XmlMarshaller.XMLLocation;
import iristk.system.Event;
import iristk.flow.*;
import iristk.util.Record;
import static iristk.util.Converters.*;
import static iristk.flow.State.*;
import iristk.furhat.util.Localizer;

public class PresentationFlow extends iristk.flow.Flow {

	private iristk.situated.SystemAgentFlow agent;
	private Localizer translator;
	private Record settings;
	private iristk.situated.SystemAgent system;
	private String defaultVoice;
	private String femaleVoice;
	private String femaleTexture;
	private String avatarTexture;

	private void initVariables() {
		system = (iristk.situated.SystemAgent) agent.getSystemAgent();
	}

	public iristk.situated.SystemAgent getSystem() {
		return this.system;
	}

	public void setSystem(iristk.situated.SystemAgent value) {
		this.system = value;
	}

	public String getDefaultVoice() {
		return this.defaultVoice;
	}

	public void setDefaultVoice(String value) {
		this.defaultVoice = value;
	}

	public String getFemaleVoice() {
		return this.femaleVoice;
	}

	public void setFemaleVoice(String value) {
		this.femaleVoice = value;
	}

	public String getFemaleTexture() {
		return this.femaleTexture;
	}

	public void setFemaleTexture(String value) {
		this.femaleTexture = value;
	}

	public String getAvatarTexture() {
		return this.avatarTexture;
	}

	public void setAvatarTexture(String value) {
		this.avatarTexture = value;
	}

	public iristk.situated.SystemAgentFlow getAgent() {
		return this.agent;
	}

	public Localizer getTranslator() {
		return this.translator;
	}

	public Record getSettings() {
		return this.settings;
	}

	@Override
	public Object getVariable(String name) {
		if (name.equals("system")) return this.system;
		if (name.equals("defaultVoice")) return this.defaultVoice;
		if (name.equals("femaleVoice")) return this.femaleVoice;
		if (name.equals("femaleTexture")) return this.femaleTexture;
		if (name.equals("avatarTexture")) return this.avatarTexture;
		if (name.equals("agent")) return this.agent;
		if (name.equals("translator")) return this.translator;
		if (name.equals("settings")) return this.settings;
		return null;
	}


	public PresentationFlow(iristk.situated.SystemAgentFlow agent, Localizer translator, Record settings) {
		this.agent = agent;
		this.translator = translator;
		this.settings = settings;
		initVariables();
	}

	@Override
	public State getInitialState() {return new init();}


	public class init extends State implements Initial {

		final State currentState = this;


		@Override
		public void setFlowThread(FlowRunner.FlowThread flowThread) {
			super.setFlowThread(flowThread);
		}

		@Override
		public void onentry() throws Exception {
			int eventResult;
			Event event = new Event("state.enter");
			// Line: 22
			try {
				EXECUTION: {
					int count = getCount(1607460018) + 1;
					incrCount(1607460018);
					// Line: 23
					defaultVoice = translator.get("MALE_VOICE");
					femaleVoice = translator.get("FEMALE_VOICE");
					femaleTexture = "Anne";
					avatarTexture = "Avatar";
					// Line: 30
					part1 state0 = new part1();
					flowThread.gotoState(state0, currentState, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 30, 34)));
					eventResult = EVENT_ABORTED;
					break EXECUTION;
				}
			} catch (Exception e) {
				throw new FlowException(e, currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 22, 18));
			}
		}

		@Override
		public int onFlowEvent(Event event) throws Exception {
			int eventResult;
			int count;
			eventResult = super.onFlowEvent(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			eventResult = callerHandlers(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			return EVENT_IGNORED;
		}

	}


	private class part1 extends IdleMoves {

		final State currentState = this;


		@Override
		public void setFlowThread(FlowRunner.FlowThread flowThread) {
			super.setFlowThread(flowThread);
		}

		@Override
		public void onentry() throws Exception {
			int eventResult;
			Event event = new Event("state.enter");
			// Line: 35
			try {
				EXECUTION: {
					int count = getCount(1940447180) + 1;
					incrCount(1940447180);
					// Line: 36
					Event sendEvent1 = new Event("action.voice");
					sendEvent1.putIfNotNull("name", defaultVoice);
					flowRunner.sendEvent(sendEvent1, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 36, 55)));
					// Line: 37
					Event sendEvent2 = new Event("action.face.texture");
					sendEvent2.putIfNotNull("name", "default");
					flowRunner.sendEvent(sendEvent2, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 37, 59)));
					// Line: 38
					lookAtRandomPerson state3 = new lookAtRandomPerson();
					if (!flowThread.callState(state3, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 38, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 39
					iristk.flow.DialogFlow.wait waitState4 = new iristk.flow.DialogFlow.wait();
					waitState4.setMsec(500);
					if (!flowThread.callState(waitState4, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 39, 23)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 41
					lookAtRandomPerson state5 = new lookAtRandomPerson();
					if (!flowThread.callState(state5, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 41, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state6 = agent.new say();
					state6.setText(translator.get("HELLO_THERE"));
					if (!flowThread.callState(state6, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 43
					iristk.flow.DialogFlow.wait waitState7 = new iristk.flow.DialogFlow.wait();
					waitState7.setMsec(100);
					if (!flowThread.callState(waitState7, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 43, 23)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 45
					Event sendEvent8 = new Event("action.gesture");
					sendEvent8.putIfNotNull("name", "smile");
					flowRunner.sendEvent(sendEvent8, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 45, 52)));
					iristk.situated.SystemAgentFlow.say state9 = agent.new say();
					state9.setText(translator.get("MY_NAME_IS_FURHAT"));
					if (!flowThread.callState(state9, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 47
					Event sendEvent10 = new Event("action.gesture");
					sendEvent10.putIfNotNull("name", "smile");
					flowRunner.sendEvent(sendEvent10, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 47, 52)));
					// Line: 48
					lookAtRandomPerson state11 = new lookAtRandomPerson();
					if (!flowThread.callState(state11, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 48, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state12 = agent.new say();
					state12.setText(translator.get("I_CAN_SHOW_EMOTIONS"));
					if (!flowThread.callState(state12, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 50
					Event sendEvent13 = new Event("action.gesture");
					sendEvent13.putIfNotNull("name", "emotion_anger");
					flowRunner.sendEvent(sendEvent13, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 50, 60)));
					// Line: 51
					iristk.flow.DialogFlow.wait waitState14 = new iristk.flow.DialogFlow.wait();
					waitState14.setMsec(1000);
					if (!flowThread.callState(waitState14, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 51, 24)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 53
					lookAtRandomPerson state15 = new lookAtRandomPerson();
					if (!flowThread.callState(state15, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 53, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 54
					Event sendEvent16 = new Event("action.gesture");
					sendEvent16.putIfNotNull("name", "emotion_neutral");
					flowRunner.sendEvent(sendEvent16, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 54, 61)));
					iristk.situated.SystemAgentFlow.say state17 = agent.new say();
					state17.setText(translator.get("I_CAN_HAVE_PERSONALITIES"));
					if (!flowThread.callState(state17, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 56
					Event sendEvent18 = new Event("action.face.texture");
					sendEvent18.putIfNotNull("name", femaleTexture);
					flowRunner.sendEvent(sendEvent18, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 56, 63)));
					iristk.situated.SystemAgentFlow.say state19 = agent.new say();
					state19.setText(translator.get("I_CAN_LOOK_FEMALE"));
					if (!flowThread.callState(state19, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 58
					lookAtRandomPerson state20 = new lookAtRandomPerson();
					if (!flowThread.callState(state20, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 58, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 59
					Event sendEvent21 = new Event("action.voice");
					sendEvent21.putIfNotNull("name", femaleVoice);
					flowRunner.sendEvent(sendEvent21, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 59, 54)));
					iristk.situated.SystemAgentFlow.say state22 = agent.new say();
					state22.setText(translator.get("AND_SOUND_FEMALE"));
					if (!flowThread.callState(state22, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 61
					lookAtRandomPerson state23 = new lookAtRandomPerson();
					if (!flowThread.callState(state23, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 61, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 62
					Event sendEvent24 = new Event("action.voice");
					sendEvent24.putIfNotNull("name", defaultVoice);
					flowRunner.sendEvent(sendEvent24, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 62, 55)));
					iristk.situated.SystemAgentFlow.say state25 = agent.new say();
					state25.setText(translator.get("OR_LIKE_ANYONE_ELSE"));
					if (!flowThread.callState(state25, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 64
					lookAtRandomPerson state26 = new lookAtRandomPerson();
					if (!flowThread.callState(state26, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 64, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 65
					Event sendEvent27 = new Event("action.face.texture");
					sendEvent27.putIfNotNull("name", avatarTexture);
					flowRunner.sendEvent(sendEvent27, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 65, 63)));
					iristk.situated.SystemAgentFlow.say state28 = agent.new say();
					state28.setText(translator.get("LIKE_AN_AVATAR"));
					if (!flowThread.callState(state28, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 67
					Event sendEvent29 = new Event("action.voice");
					sendEvent29.putIfNotNull("name", defaultVoice);
					flowRunner.sendEvent(sendEvent29, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 67, 55)));
					// Line: 68
					if (eq(defaultVoice, "william")) {
						iristk.situated.SystemAgentFlow.say state30 = agent.new say();
						StringCreator string31 = new StringCreator();
						string31.append("GESTURE_GIGGLE_2");
						state30.setText(string31.toString());
						if (!flowThread.callState(state30, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 68, 43)))) {
							eventResult = EVENT_ABORTED;
							break EXECUTION;
						}
						// Line: 70
					} else {
						iristk.situated.SystemAgentFlow.say state32 = agent.new say();
						state32.setText(translator.get("GESTURE_BREATH_IN"));
						if (!flowThread.callState(state32, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 68, 43)))) {
							eventResult = EVENT_ABORTED;
							break EXECUTION;
						}
					}
					// Line: 73
					lookAtRandomPerson state33 = new lookAtRandomPerson();
					if (!flowThread.callState(state33, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 73, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 74
					Event sendEvent34 = new Event("action.face.texture");
					sendEvent34.putIfNotNull("name", "default");
					flowRunner.sendEvent(sendEvent34, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 74, 59)));
					// Line: 75
					iristk.flow.DialogFlow.wait waitState35 = new iristk.flow.DialogFlow.wait();
					waitState35.setMsec(500);
					if (!flowThread.callState(waitState35, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 75, 23)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 76
					lookAtRandomPerson state36 = new lookAtRandomPerson();
					if (!flowThread.callState(state36, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 76, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state37 = agent.new say();
					state37.setText(translator.get("INSIDE_MY_CHEST_FURHATOS"));
					if (!flowThread.callState(state37, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 78
					lookAtRandomPerson state38 = new lookAtRandomPerson();
					if (!flowThread.callState(state38, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 78, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state39 = agent.new say();
					state39.setText(translator.get("IT_CONNECTS_ME_TO_SENSORS"));
					if (!flowThread.callState(state39, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 80
					iristk.flow.DialogFlow.wait waitState40 = new iristk.flow.DialogFlow.wait();
					waitState40.setMsec(1200);
					if (!flowThread.callState(waitState40, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 80, 24)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 82
					lookAtRandomPerson state41 = new lookAtRandomPerson();
					if (!flowThread.callState(state41, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 82, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state42 = agent.new say();
					StringCreator string43 = new StringCreator();
					string43.append("GESTURE_SIGH_HAPPY");
					state42.setText(string43.toString());
					if (!flowThread.callState(state42, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 84
					iristk.flow.DialogFlow.wait waitState44 = new iristk.flow.DialogFlow.wait();
					waitState44.setMsec(300);
					if (!flowThread.callState(waitState44, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 84, 23)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state45 = agent.new say();
					state45.setText(translator.get("EXCITING_TIMES"));
					if (!flowThread.callState(state45, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 87
					iristk.flow.DialogFlow.wait waitState46 = new iristk.flow.DialogFlow.wait();
					waitState46.setMsec(100);
					if (!flowThread.callState(waitState46, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 87, 23)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state47 = agent.new say();
					state47.setText(translator.get("I_BELIEVE_GREAT_THINGS_ARE_HAPPENING"));
					if (!flowThread.callState(state47, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state48 = agent.new say();
					state48.setText(translator.get("BETWEEN_ROBOTS_AND_HUMANS"));
					if (!flowThread.callState(state48, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 90
					lookAtRandomPerson state49 = new lookAtRandomPerson();
					if (!flowThread.callState(state49, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 90, 39)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 91
					iristk.flow.DialogFlow.wait waitState50 = new iristk.flow.DialogFlow.wait();
					waitState50.setMsec(200);
					if (!flowThread.callState(waitState50, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 91, 23)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state51 = agent.new say();
					state51.setText(translator.get("HAPPY_TO_BE_HERE"));
					if (!flowThread.callState(state51, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					iristk.situated.SystemAgentFlow.say state52 = agent.new say();
					state52.setText(translator.get("LOOKING_FORWARD_TO_GET_TO_KNOW_YOU"));
					if (!flowThread.callState(state52, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
					// Line: 94
					if (settings.has("personToPassOverTo")) {
						// Line: 95
						iristk.flow.DialogFlow.wait waitState53 = new iristk.flow.DialogFlow.wait();
						waitState53.setMsec(500);
						if (!flowThread.callState(waitState53, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 95, 24)))) {
							eventResult = EVENT_ABORTED;
							break EXECUTION;
						}
						// Line: 96
						Event sendEvent54 = new Event("action.gesture");
						sendEvent54.putIfNotNull("name", "wink");
						flowRunner.sendEvent(sendEvent54, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 96, 51)));
						iristk.situated.SystemAgentFlow.say state55 = agent.new say();
						StringCreator string56 = new StringCreator();
						string56.append("Thanks for me, over to you");
						// Line: 96
						string56.append(settings.get("personToPassOverTo"));
						state55.setText(string56.toString());
						if (!flowThread.callState(state55, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 94, 44)))) {
							eventResult = EVENT_ABORTED;
							break EXECUTION;
						}
					}
					// Line: 99
					Event sendEvent57 = new Event("action.gesture");
					sendEvent57.putIfNotNull("name", "smile");
					flowRunner.sendEvent(sendEvent57, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 99, 52)));
					// Line: 100
					PostPres state58 = new PostPres();
					flowThread.gotoState(state58, currentState, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 100, 28)));
					eventResult = EVENT_ABORTED;
					break EXECUTION;
				}
			} catch (Exception e) {
				throw new FlowException(e, currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 35, 12));
			}
		}

		@Override
		public int onFlowEvent(Event event) throws Exception {
			int eventResult;
			int count;
			eventResult = super.onFlowEvent(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			eventResult = callerHandlers(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			return EVENT_IGNORED;
		}

	}


	private class PostPres extends IdleMoves {

		final State currentState = this;


		@Override
		public void setFlowThread(FlowRunner.FlowThread flowThread) {
			super.setFlowThread(flowThread);
			flowThread.addEventClock(16000, 32000, "timer_1404928347");
		}

		@Override
		public void onentry() throws Exception {
			int eventResult;
			Event event = new Event("state.enter");
		}

		@Override
		public int onFlowEvent(Event event) throws Exception {
			int eventResult;
			int count;
			// Line: 105
			count = getCount(1404928347) + 1;
			if (event.triggers("timer_1404928347")) {
				incrCount(1404928347);
				eventResult = EVENT_CONSUMED;
				EXECUTION: {
					// Line: 106
					if (settings.has("shouldCough") && eq(defaultVoice, "william")) {
						// Line: 107
						boolean chosen59 = false;
						boolean matching60 = true;
						while (!chosen59 && matching60) {
							int rand61 = random(123961122, 2, iristk.util.RandomList.RandomModel.DECK_RESHUFFLE_NOREPEAT);
							matching60 = false;
							if (true) {
								matching60 = true;
								if (rand61 >= 0 && rand61 < 1) {
									chosen59 = true;
									iristk.situated.SystemAgentFlow.say state62 = agent.new say();
									StringCreator string63 = new StringCreator();
									string63.append("GESTURE_SNIFF_1");
									state62.setText(string63.toString());
									if (!flowThread.callState(state62, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 107, 19)))) {
										eventResult = EVENT_ABORTED;
										break EXECUTION;
									}
								}
							}
							if (true) {
								matching60 = true;
								if (rand61 >= 1 && rand61 < 2) {
									chosen59 = true;
									iristk.situated.SystemAgentFlow.say state64 = agent.new say();
									StringCreator string65 = new StringCreator();
									string65.append("GESTURE_COUGH_2");
									state64.setText(string65.toString());
									if (!flowThread.callState(state64, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 107, 19)))) {
										eventResult = EVENT_ABORTED;
										break EXECUTION;
									}
								}
							}
						}
					}
				}
				if (eventResult != EVENT_IGNORED) return eventResult;
			}
			eventResult = super.onFlowEvent(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			eventResult = callerHandlers(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			return EVENT_IGNORED;
		}

	}


	private class lookAtRandomPerson extends State {

		final State currentState = this;


		@Override
		public void setFlowThread(FlowRunner.FlowThread flowThread) {
			super.setFlowThread(flowThread);
		}

		@Override
		public void onentry() throws Exception {
			int eventResult;
			Event event = new Event("state.enter");
			// Line: 116
			try {
				EXECUTION: {
					int count = getCount(1982791261) + 1;
					incrCount(1982791261);
					// Line: 117
					if (system.hasUsers()) {
						iristk.situated.SystemAgentFlow.attendOther state66 = agent.new attendOther();
						if (!flowThread.callState(state66, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 117, 33)))) {
							eventResult = EVENT_ABORTED;
							break EXECUTION;
						}
						// Line: 120
					} else {
						// Line: 122
						boolean chosen67 = false;
						boolean matching68 = true;
						while (!chosen67 && matching68) {
							int rand69 = random(942731712, 5, iristk.util.RandomList.RandomModel.DECK_RESHUFFLE_NOREPEAT);
							matching68 = false;
							if (true) {
								matching68 = true;
								if (rand69 >= 0 && rand69 < 1) {
									chosen67 = true;
									iristk.situated.SystemAgentFlow.attend state70 = agent.new attend();
									state70.setX(0.5);
									state70.setY(0);
									state70.setZ(1);
									if (!flowThread.callState(state70, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 122, 13)))) {
										eventResult = EVENT_ABORTED;
										break EXECUTION;
									}
								}
							}
							if (true) {
								matching68 = true;
								if (rand69 >= 1 && rand69 < 2) {
									chosen67 = true;
									iristk.situated.SystemAgentFlow.attend state71 = agent.new attend();
									state71.setX(0.2);
									state71.setY(0);
									state71.setZ(1);
									if (!flowThread.callState(state71, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 122, 13)))) {
										eventResult = EVENT_ABORTED;
										break EXECUTION;
									}
								}
							}
							if (true) {
								matching68 = true;
								if (rand69 >= 2 && rand69 < 3) {
									chosen67 = true;
									iristk.situated.SystemAgentFlow.attend state72 = agent.new attend();
									state72.setX(-0.5);
									state72.setY(0.1);
									state72.setZ(1);
									if (!flowThread.callState(state72, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 122, 13)))) {
										eventResult = EVENT_ABORTED;
										break EXECUTION;
									}
								}
							}
							if (true) {
								matching68 = true;
								if (rand69 >= 3 && rand69 < 4) {
									chosen67 = true;
									iristk.situated.SystemAgentFlow.attend state73 = agent.new attend();
									state73.setX(-0.2);
									state73.setY(-0.1);
									state73.setZ(1);
									if (!flowThread.callState(state73, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 122, 13)))) {
										eventResult = EVENT_ABORTED;
										break EXECUTION;
									}
								}
							}
							if (true) {
								matching68 = true;
								if (rand69 >= 4 && rand69 < 5) {
									chosen67 = true;
									iristk.situated.SystemAgentFlow.attend state74 = agent.new attend();
									state74.setX(0);
									state74.setY(0);
									state74.setZ(1);
									if (!flowThread.callState(state74, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 122, 13)))) {
										eventResult = EVENT_ABORTED;
										break EXECUTION;
									}
								}
							}
						}
					}
					// Line: 130
					flowThread.returnFromCall(this, null, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 130, 14)));
					eventResult = EVENT_ABORTED;
					break EXECUTION;
				}
			} catch (Exception e) {
				throw new FlowException(e, currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 116, 12));
			}
		}

		@Override
		public int onFlowEvent(Event event) throws Exception {
			int eventResult;
			int count;
			eventResult = super.onFlowEvent(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			eventResult = callerHandlers(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			return EVENT_IGNORED;
		}

	}


	private class IdleMoves extends State {

		final State currentState = this;


		@Override
		public void setFlowThread(FlowRunner.FlowThread flowThread) {
			super.setFlowThread(flowThread);
			flowThread.addEventClock(4000, 8000, "timer_758529971");
			flowThread.addEventClock(3000, 10000, "timer_1521118594");
		}

		@Override
		public void onentry() throws Exception {
			int eventResult;
			Event event = new Event("state.enter");
		}

		@Override
		public int onFlowEvent(Event event) throws Exception {
			int eventResult;
			int count;
			// Line: 135
			count = getCount(758529971) + 1;
			if (event.triggers("timer_758529971")) {
				incrCount(758529971);
				eventResult = EVENT_CONSUMED;
				EXECUTION: {
					// Line: 137
					boolean chosen75 = false;
					boolean matching76 = true;
					while (!chosen75 && matching76) {
						int rand77 = random(2104457164, 5, iristk.util.RandomList.RandomModel.DECK_RESHUFFLE_NOREPEAT);
						matching76 = false;
						if (true) {
							matching76 = true;
							if (rand77 >= 0 && rand77 < 1) {
								chosen75 = true;
								iristk.situated.SystemAgentFlow.gesture state78 = agent.new gesture();
								state78.setAsync(true);
								state78.setName("phone_oh");
								if (!flowThread.callState(state78, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 137, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
						if (true) {
							matching76 = true;
							if (rand77 >= 1 && rand77 < 2) {
								chosen75 = true;
								iristk.situated.SystemAgentFlow.gesture state79 = agent.new gesture();
								state79.setAsync(true);
								state79.setName("surprise");
								if (!flowThread.callState(state79, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 137, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
						if (true) {
							matching76 = true;
							if (rand77 >= 2 && rand77 < 3) {
								chosen75 = true;
								iristk.situated.SystemAgentFlow.gesture state80 = agent.new gesture();
								state80.setAsync(true);
								state80.setName("shy");
								if (!flowThread.callState(state80, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 137, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
						if (true) {
							matching76 = true;
							if (rand77 >= 3 && rand77 < 4) {
								chosen75 = true;
								iristk.situated.SystemAgentFlow.gesture state81 = agent.new gesture();
								state81.setAsync(true);
								state81.setName("smile");
								if (!flowThread.callState(state81, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 137, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
						if (true) {
							matching76 = true;
							if (rand77 >= 4 && rand77 < 5) {
								chosen75 = true;
								iristk.situated.SystemAgentFlow.gesture state82 = agent.new gesture();
								state82.setAsync(true);
								state82.setName("thoughtful");
								if (!flowThread.callState(state82, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 137, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
					}
				}
				if (eventResult != EVENT_IGNORED) return eventResult;
			}
			// Line: 145
			count = getCount(1521118594) + 1;
			if (event.triggers("timer_1521118594")) {
				incrCount(1521118594);
				eventResult = EVENT_CONSUMED;
				EXECUTION: {
					// Line: 147
					boolean chosen83 = false;
					boolean matching84 = true;
					while (!chosen83 && matching84) {
						int rand85 = random(1940030785, 5, iristk.util.RandomList.RandomModel.DECK_RESHUFFLE_NOREPEAT);
						matching84 = false;
						if (true) {
							matching84 = true;
							if (rand85 >= 0 && rand85 < 1) {
								chosen83 = true;
								iristk.situated.SystemAgentFlow.attend state86 = agent.new attend();
								state86.setX(0.2);
								state86.setY(0.1);
								state86.setZ(1);
								if (!flowThread.callState(state86, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 147, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
						if (true) {
							matching84 = true;
							if (rand85 >= 1 && rand85 < 2) {
								chosen83 = true;
								iristk.situated.SystemAgentFlow.attend state87 = agent.new attend();
								state87.setX(0.2);
								state87.setY(-0.1);
								state87.setZ(1);
								if (!flowThread.callState(state87, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 147, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
						if (true) {
							matching84 = true;
							if (rand85 >= 2 && rand85 < 3) {
								chosen83 = true;
								iristk.situated.SystemAgentFlow.attend state88 = agent.new attend();
								state88.setX(-0.2);
								state88.setY(0.1);
								state88.setZ(1);
								if (!flowThread.callState(state88, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 147, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
						if (true) {
							matching84 = true;
							if (rand85 >= 3 && rand85 < 4) {
								chosen83 = true;
								iristk.situated.SystemAgentFlow.attend state89 = agent.new attend();
								state89.setX(-0.2);
								state89.setY(-0.1);
								state89.setZ(1);
								if (!flowThread.callState(state89, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 147, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
						if (true) {
							matching84 = true;
							if (rand85 >= 4 && rand85 < 5) {
								chosen83 = true;
								iristk.situated.SystemAgentFlow.attend state90 = agent.new attend();
								state90.setX(0);
								state90.setY(0);
								state90.setZ(1);
								if (!flowThread.callState(state90, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 147, 12)))) {
									eventResult = EVENT_ABORTED;
									break EXECUTION;
								}
							}
						}
					}
					iristk.situated.SystemAgentFlow.attend state91 = agent.new attend();
					state91.setMode("eyes");
					state91.setX(0);
					state91.setY(0);
					state91.setZ(1);
					if (!flowThread.callState(state91, new FlowEventInfo(currentState, event, new XMLLocation(new File("C:\\Users\\ludvig\\dev\\furhat\\example-skills\\presentation\\src\\iristk\\app\\presentation\\PresentationFlow.xml"), 145, 33)))) {
						eventResult = EVENT_ABORTED;
						break EXECUTION;
					}
				}
				if (eventResult != EVENT_IGNORED) return eventResult;
			}
			eventResult = super.onFlowEvent(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			eventResult = callerHandlers(event);
			if (eventResult != EVENT_IGNORED) return eventResult;
			return EVENT_IGNORED;
		}

	}


}
